Previously MiniUtils

### WHAT'S NEW IN THIS VERSION?
{latest_change}

## Welcome to the create-machine-utils module
Here at ClicksMinutePer we make discord bots. We do it so often infact that we often get a little annoyed at stuff that discord.py does badly, such as creating embeds<br/>
We also don't like some stuff in python, such as the builtin json module, inputting values that aren't strings etc.<br/>

create-machine-utils is the solution, at least for us: we've made it simpler (for us) to do stuff that needs doing (by us).
We think it's better but honestly: you might just prefer normal python; that's ok too!
Whatever way you decide, we hope you enjoy using ~~miniutils~~ <sup>You can't call it that anymore minion: someone over here already has that package name</sup> <sub>Oh, my bad... sorry.</sub> create machine utils

### FULL CHANGELOG
{changelog}