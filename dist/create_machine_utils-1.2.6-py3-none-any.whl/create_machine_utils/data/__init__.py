from . import json

Json = json.Json

__all__ = (
    Json
)
